# vim: ts=4 sts=4 sw=4
package eleMentalClinic::Role::ClientPermission;
use strict;
use warnings;
use eleMentalClinic::Role;
use eleMentalClinic::Role::Cache qw/resets_role_cache/;
use eleMentalClinic::Client;
use eleMentalClinic::Client::Placement::Event;

use base qw/ eleMentalClinic::DB::Object /;

=head1 NAME

eleMentalClinic::Role::ClientPermission

=head1 DESCRIPTION

A permission object granting permissions against a client to a specific role.

=head1 METHODS

=over 4

=item role()

Returns the role in this permission.

=item client()

Returns the client in this permission.

=cut

sub table  { 'personnel_role_client_permission' }
sub fields {[ qw/ rec_id role_id client_id /]}
sub methods {[ qw/ service_coordinator /]}
sub primary_key { 'rec_id' }
resets_role_cache qw/save update delete/;

sub accessors_retrieve_one {
    {
        role => { role_id => 'eleMentalClinic::Role' },
        client => { client_id => 'eleMentalClinic::Client' },
    };
}

=item $list = get_for_service_coordinators()

Returns a list of unique permission objects. There will be an object for every
staff-client association created by a placement event. Duplicates have been
stripped. These objects will refuse to save as they are not direct
associations.

=cut

sub get_for_service_coordinators {
    my $class = shift;
    my $list = eleMentalClinic::Client::Placement::Event->get_all;
    return $class->_build_for_coordinators( $list );
}

=item $list = get_for_service_coordinators_by_staff( $staff_id )

Same as get_for_service_coordinators() except the results are filtered by
staff.

=cut

sub get_for_service_coordinators_by_staff {
    my $class = shift;
    my ( $staff_id ) = @_;
    my $list = eleMentalClinic::Client::Placement::Event->get_by_( 'staff_id', $staff_id );
    return $class->_build_for_coordinators( $list );
}

=item $list = get_for_service_coordinators_by_client( $client_id )

Same as get_for_service_coordinators() except the results are filtered by
client.

=cut

sub get_for_service_coordinators_by_client {
    my $class = shift;
    my ( $client_id ) = @_;
    my $list = eleMentalClinic::Client::Placement::Event->get_by_( 'client_id', $client_id );
    return $class->_build_for_coordinators( $list );
}

=item $list = _build_for_coordinators( $event_list )

Takes a list of placement events and returns a list of permissions.

=cut

sub _build_for_coordinators {
    my $class = shift;
    my ( $list ) = @_;

    my %unique;
    $unique{ $_->personnel->primary_role->id }{ $_->client_id }++
        for grep { $_->staff_id and $_->client_id } @$list;

    my @out;
    for my $role_id ( keys %unique ) {
        for my $client_id ( keys %{ $unique{ $role_id }}) {
            my $new = __PACKAGE__->new({ role_id => $role_id, client_id => $client_id });
            $new->service_coordinator( 1 );
            push @out => $new;
        }
    }

    return \@out;
}

sub save {
    my $self = shift;
    if ( $self->service_coordinator ) {
        warn( "Attempted to save a client permission associated with a service coordinator." );
        return;
    }
    return $self->SUPER::save( @_ );
}

sub delete {
    my $self = shift;
    if ( $self->service_coordinator) {
        warn( "Attempted to delete a client permission associated with a service coordinator." );
        return;
    }
    return $self->SUPER::delete( @_ );
}

'eleMental';

__END__

=back

=head1 AUTHORS

=over 4

=item Chad Granum L<chad@opensourcery.com>

=back

=head1 BUGS

We strive for perfection but are, in fact, mortal.  Please see L<https://prefect.opensourcery.com:444/projects/elementalclinic/report/1> for known bugs.

=head1 SEE ALSO

=over 4

=item Project web site at: L<http://elementalclinic.org>

=item Code management site at: L<https://prefect.opensourcery.com:444/projects/elementalclinic/>

=back

=head1 COPYRIGHT

Copyright (C) 2004-2009 OpenSourcery, LLC

This file is part of eleMental Clinic.

eleMental Clinic is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the Free
Software Foundation; either version 2 of the License, or (at your option) any
later version.

eleMental Clinic is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with
this program; if not, write to the Free Software Foundation, Inc., 51 Franklin
Street, Fifth Floor, Boston, MA 02110-1301 USA.

eleMental Clinic is packaged with a copy of the GNU General Public License.
Please see docs/COPYING in this distribution.

# vim: ts=4 sts=4 sw=4
package eleMentalClinic::Controller::Base::Demographics;
use strict;
use warnings;

=head1 NAME

eleMentalClinic::Controller::Default::Demographics

=head1 SYNOPSIS

Base Demographics Controller.

=head1 METHODS

=cut

use base qw/ eleMentalClinic::CGI::Rolodex /;
use eleMentalClinic::Client;
use eleMentalClinic::Client::Referral;
use eleMentalClinic::Rolodex;
use eleMentalClinic::Contact::Address;
use eleMentalClinic::Contact::Phone;
use Data::Dumper;
use Scalar::Util qw(blessed);

# this isn't very robust, but it can be replaced once Moose is hooked deeper
# into emC's guts.
sub clone {
    my $self = shift;
    return bless { %$self, @_ }, blessed $self;
}

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
sub init {
    my $self = shift;
    my( $args ) = @_;

    $self->SUPER::init( $args );
    $self->template->vars({
        styles => [ 'layout/6633', 'demographics' ],
        script => 'demographics.cgi',
        use_new_date_picker => 1,
    });
    return $self;
}

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
sub ops {
    (
        home => {
            -alias => 'Cancel',
        },
        edit => {
            -alias => 'Edit',
        },
        save => {
            -alias => 'Save Client',
            -on_error => 'edit',
            address1            => [ 'Street address', 'required' ],
            client_id           => [ 'Client', 'required' ],
            city                => [ 'City', 'required' ],
            state               => [ 'State', 'demographics::us_state2', 'required' ],
            post_code           => [ 'Zip code', 'number::integer', 'required' ],
            ssn                 => [ 'Social Security number', 'demographics::us_ssn(integer)' ],
            dob                 => [ 'Birthdate', 'date::iso(past,present)' ],
            aka                 => [ 'Alias', 'length(0,25)' ],
            state_specific_id   => [ 'CPMS', 'number' ],
            phone_number        => [ 'Phone number', 'length(0,18)' ],
            send_notifications  => [ 'Send email notifications', 'checkbox::boolean' ],
        },
    )
}

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
sub home {
    my $self = shift;

    return {
    };
}

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
sub edit {
    my $self = shift;
    my( $current ) = @_;

    $self->override_template_name( 'home' );
    return {
        op => 'edit',
        current         => $current,
    };
}

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
sub save {
    my $self = shift;

    if( $self->errors ) {
        return $self->on_error;
    }
    else {
        my $rv;
        $self->db->transaction_do(sub { $rv = $self->on_success });
        return $rv;
    }
}

sub on_error {
    my $self = shift;
    $self->clone(
        client => $self->client->new({ $self->Vars }),
    )->edit;
}

sub on_success {
    my $self = shift;
    my $client = $self->client;
    $self->save_phone( $client, $self->param( 'phone_number' ));
    $self->save_address( $client, { $self->Vars } );
    $client->update({ $self->Vars });
    return $self->edit;
}

'eleMental';

__END__

=head1 AUTHORS

=over 4

=item Chad Granum L<chad@opensourcery.com>

=item Randall Hansen L<randall@opensourcery.com>

=item Kirsten Comandich L<kirsten@opensourcery.com>

=item Josh Heumann L<josh@joshheumann.com>

=back

=head1 BUGS

We strive for perfection but are, in fact, mortal.  Please see L<https://prefect.opensourcery.com:444/projects/elementalclinic/report/1> for known bugs.

=head1 SEE ALSO

=over 4

=item Project web site at: L<http://elementalclinic.org>

=item Code management site at: L<https://prefect.opensourcery.com:444/projects/elementalclinic/>

=back

=head1 COPYRIGHT

Copyright (C) 2004-2007 OpenSourcery, LLC

This file is part of eleMental Clinic.

eleMental Clinic is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the Free
Software Foundation; either version 2 of the License, or (at your option) any
later version.

eleMental Clinic is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with
this program; if not, write to the Free Software Foundation, Inc., 51 Franklin
Street, Fifth Floor, Boston, MA 02110-1301 USA.

eleMental Clinic is packaged with a copy of the GNU General Public License.
Please see docs/COPYING in this distribution.

package eleMentalClinic;
eval 'use eleMentalClinic::deps';

our $VERSION = '5.05';

1;

__END__

=head1 NAME

eleMentalClinic - a different kind of EMR

=cut

# vim: ts=4 sts=4 sw=4
package eleMentalClinic::Role;
use strict;
use warnings;
use eleMentalClinic::Util;
use eleMentalClinic::Personnel;
use eleMentalClinic::Role::Cache qw/cache_methods resets_role_cache/;
use eleMentalClinic::Role::Member;
use eleMentalClinic::Role::ClientPermission;
use eleMentalClinic::Role::GroupPermission;
use Data::Dumper;

use base qw/ eleMentalClinic::DB::Object /;

=head1 NAME

eleMentalClinic::Role

=head1 DESCRIPTION

Roles are essentially groups that clinicians are associated with. There are
system roles and clinician roles. Roles can be members of other roles.

=head1 METHODS

=over 4

=cut

sub table  { 'personnel_role' }
sub fields { [ qw/ rec_id name staff_id system_role has_homepage special_name / ] }
sub primary_key { 'rec_id' }

# To build the fields and accessors
__PACKAGE__->new({});

cache_methods qw/ direct_members direct_parents all_members all_parents
    direct_personnel all_personnel service_coordinator_permissions
    all_client_permissions has_all_groups_role all_group_permissions
    _parent_roles/;

resets_role_cache qw/save update delete add_member add_members del_member
    del_members add_personnel del_personnel grant_client_permission
    grant_client_permissions revoke_client_permission revoke_client_permissions
    grant_group_permission grant_group_permissions revoke_group_permission
    revoke_group_permissions/;


=item $role = all_clients_role()

retrieve the 'all clients' special role

=item $role = all_groups_role()

retrieve the 'all groups' special role

=item $role = admin_role()

retrieve the 'admin' special role

=cut

sub all_clients_role { shift->special_role( 'all_clients' )}
sub all_groups_role { shift->special_role( 'all_groups' )}
sub admin_role { shift->special_role( 'admin' )}
sub limited_all_access_names { qw/financial reports/ }
sub limited_all_access_roles { return [
    map { __PACKAGE__->get_one_by_( name => $_ )}
        (limited_all_access_names())
]}

=item $role = special_role( $special_name )

Retrieve a special role by name.

=cut

sub special_role {
    my $self = shift;
    my $class = ref $self || $self;
    my ( $special ) = @_;
    return $class->get_one_by_( special_name => $special );
}

sub accessors_retrieve_many {
    {
        direct_members => { role_id => 'eleMentalClinic::Role::Member' },
        direct_parents => { member_id => 'eleMentalClinic::Role::Member' },
        direct_client_permissions => { role_id => 'eleMentalClinic::Role::ClientPermission' },
        direct_group_permissions => { role_id => 'eleMentalClinic::Role::GroupPermission' },
    };
}

#{{{ Membership related methods

=item direct_members()

Returns an arrayref of eleMentalClinic::Role::Member objects where this role is the
parent role.

=item direct_parents()

Returns an arrayref of eleMentalClinic::Role::Member objects where this role is the
member role.

=item all_members()

Returns an arrayref with all the member objects that effect this role. This
includes direct members, as well as members of members.

=cut

sub all_members {
    my $self = shift;
    return $self->_recurse_memberships( 'direct_members', 'member' );
}


=item all_parents()

Returns an arrayref with all the member objects that are parents of this role. This
includes direct parents, as well as parents of parents.

=cut

sub all_parents {
    my $self = shift;
    return $self->_recurse_memberships( 'direct_parents', 'role' );
}

=item $member = add_member( $role )

Make the specified role a member of this one.

=cut

sub add_member {
    my $self = shift;
    my ( $member ) = @_;
    $member = $member->id if ref $member;

    my $membership = $self->has_direct_member( $member );

    return $membership if $membership;

    $membership = eleMentalClinic::Role::Member->new({
        role_id => $self->id,
        member_id => $member,
    });

    $membership->save;

    return $membership;
}

=item $members = add_members( $role1, $role2, ... )

Add multiple roles as members.

=cut

sub add_members {
    my $self = shift;
    return [ map { $self->add_member( $_ ) } @_ ];
}

=item del_member( $role )

Remove any direct memberships where the spefied role is a member of this one.

NOTE: Will not remove an indirect membership where the specified role is a
member of another member.

=cut

sub del_member {
    my $self = shift;

    my $membership = $self->has_direct_member( @_ );
    return unless $membership and $membership->id;

    $membership->delete();
}

=item del_members( $role1, $role2, ... )

Remove multiple direct members.

NOTE: Will not remove an indirect membership where the specified role is a
member of another member.

=cut

sub del_members {
    my $self = shift;
    return [ map { $self->del_member( $_ )} @_ ];
}

=item has_direct_member( $role )

Returns the eleMentalClinic::Role::Member object if the role is a direct member
of this one. Returns undef when the specified role is not a direct member.

=cut

sub has_direct_member {
    my $self = shift;
    my ( $member ) = @_;
    unless( ref $member ){
        $member = $member =~ m/^\d+$/ ? eleMentalClinic::Role->retrieve( $member )
                                      : eleMentalClinic::Role->get_one_by_( 'name', $member );
    }

    my $membership = eleMentalClinic::Role::Member->get_one_where(
        'WHERE member_id = ' . dbquote( $member->id ) . ' AND role_id = ' . dbquote( $self->id )
    );

    return unless $membership and $membership->id;
    return $membership;
}

=item has_direct_members( $role1, $role2, ... )

Returns true if all the specified roles are direct members of this one.

=cut

sub has_direct_members {
    my $self = shift;
    my @members = @_;
    my $list = $self->direct_members;
    return unless $list;
    return $self->_has_(
        $list,
        \@members,
        'member_id',
    );
}

=item has_member( $role )

Returns true if the specified role is either a direct or indirect member of
this role.

=cut

sub has_member {
    my $self = shift;
    $self->has_members( @_ );
}

=item has_members( $role1, $role2, ... )

Returns true if the specified roles are all either direct or indirect members of
this role.

=cut

sub has_members {
    my $self = shift;
    my @members = @_;
    my $list = $self->all_members;
    return unless $list;
    return $self->_has_(
        $list,
        \@members,
        'member_id',
    );
}

#}}}

#{{{ Personnel related methods

=item $personnel = direct_personnel()

Returns the eleMentalClinic::Personnel associated with this role. If the role
is a system role this will return undef.

=cut

# Cannot use accessors_retrieve_one for this because staff_id is undef for
# system roles. It causes an error.
sub direct_personnel {
    my $self = shift;
    return unless $self->staff_id;
    return eleMentalClinic::Personnel->retrieve( $self->staff_id );
}

=item $list = all_personnel()

Returns an arrayref of all eleMentalClinic::Personnel that are direct or
inderectly part of this role.

=cut

sub all_personnel {
    my $self = shift;
    my $members = $self->all_members;

    my @roles = ( $self, map { $_->member } @$members );
    my %personnel = map { $_->id => $_ } grep { $_ } map { $_->direct_personnel } @roles;

    return [ values %personnel ];
}

=item has_personnel( $personnel1, $personnel2, ... )

Returns true if all the personnel are directly or indirectly part of this role.

Arguments must all be eleMentalClinic::Personnel objects or their id's.

=cut

sub has_personnel {
    my $self = shift;
    my @personnel = @_;
    my $list = $self->all_personnel;
    return unless $list;
    return $self->_has_(
        $list,
        \@personnel,
        'staff_id',
    );
}

=item add_personnel( $personnel1, $personnel2_id, ... )

Add the specified personnel to this role. Arguments may be personnel objects or
id's.

=cut

sub add_personnel {
    my $self = shift;
    $self->_do_personnel( 'add_member', @_ );
}

=item del_personnel( $personnel1, $personnel2_id, ... )

Remove the specified personnel from this role. Arguments may be personnel objects or
id's.

NOTE: Only removes direct roles, not personnel roles that are members of members.

=cut

sub del_personnel {
    my $self = shift;
    $self->_do_personnel( 'del_member', @_ );
}

#}}}

#{{{ client permission related methods

=item is_all_clients_role()

Returns true if this is the all_clients special role.

=cut

sub is_all_clients_role {
    my $self = shift;
    return 1 if $self->rec_id == $self->all_clients_role->rec_id;
    return 0;
}

=item has_all_clients_role()

Returns true if this role is a member of the all_clients role.

=cut

sub has_all_clients_role {
    my $self = shift;
    return 1 if $self->is_all_clients_role;
    return 1 if $self->all_clients_role->has_member( $self );
    return 0;
}

=item service_coordinator_permissions

Returns a list of eleMentalClinic::Role::ClientPermissions objects. One object
for each clinician-client association that is due to a placement event.

=cut

sub service_coordinator_permissions {
    my $self = shift;

    my @staff = grep { $_ } map { $_->staff_id } ( $self, @{ $self->_parent_roles });

    my @coordinators = map {
        @{ eleMentalClinic::Role::ClientPermission->get_for_service_coordinators_by_staff( $_ )}
    } @staff;

    return \@coordinators;
}

=item has_service_coordinator_permissions( @clients )

Returns true if this role has service_coordinator permissions on all the listed
clients.

=cut

sub has_service_coordinator_permissions {
    my $self = shift;
    my @clients = @_;
    my $perms = $self->service_coordinator_permissions;
    return unless $perms and @$perms;
    return $self->_has_(
        $perms,
        \@clients,
        'client_id',
    );
}

=item all_client_permissions()

Returns an arrayref of all the client permissions in this role and parent
roles.

Note: Does not include service coordinator permissions

=cut

sub all_client_permissions {
    my $self = shift;

    my @roles = ( $self, @{ $self->_parent_roles });
    my %permissions = map { $_->id => $_ } map { @{ $_->direct_client_permissions || [] }} @roles;

    return [ values %permissions ];
}

=item has_client_permission( $client )

Returns true if this role has direct or inderect permissions with the specified
client.

Argument may be eleMentalClinic::Client object or ID.

=cut

sub has_client_permission {
    my $self = shift;
    return $self->has_client_permissions( @_ );
}

=item has_client_permissions( $client1, $client2_id, ... )

Returns true if this role has direct or indirect permissions with all the
specified clients.

Arguments may be eleMentalClinic::Client object or ID.

=cut

sub has_client_permissions {
    my $self = shift;
    my $out;
    my @clients = @_;
    my $perms = $self->all_client_permissions || [];
    push @$perms => @{ $self->service_coordinator_permissions };
    if ( @$perms ) {
        $out = $self->_has_(
            $perms,
            \@clients,
            'client_id',
        );
    }
    $out ||= $self->has_all_clients_role;
    unless( $out ) {
        my @have = map { $self->has_client_permission_by_group( $_ ) } @clients;
        $out = @have && @have == @clients;
    }
    return $out;
}

=item has_client_permission_by_group( $client )

Returns true if this role has permissions on the specified client because of a
group association.

=cut

sub has_client_permission_by_group {
    my $self = shift;
    my ( $client ) = @_;
    my $client_id = ref $client ? $client->id : $client;

    my $groups = eleMentalClinic::Group->get_byclient( $client_id );
    return grep { $self->has_group_permission( $_ )} @$groups;
}

=item has_direct_client_permission( $client )

Returns true if this role has direct permissions with the specified client.

Argument may be eleMentalClinic::Client object or ID.

=cut

sub has_direct_client_permission {
    my $self = shift;
    my ( $client ) = @_;
    my $id = ref $client ? $client->id : $client;

    my $perm = eleMentalClinic::Role::ClientPermission->get_one_where(
        'WHERE role_id = ' . dbquote( $self->id ) . ' AND client_id = ' . dbquote( $id )
    );
    return $perm if $perm and $perm->id;
    return $self->is_all_clients_role;
}

=item has_client_permissions( $client1, $client2_id, ... )

Returns true if this role has direct permissions with all the specified
clients.

Arguments may be eleMentalClinic::Client object or ID.

=cut

sub has_direct_client_permissions {
    my $self = shift;
    my @clients = @_;
    my $perms = $self->direct_client_permissions;
    return unless $perms;
    return $self->_has_(
        $perms,
        \@clients,
        'client_id',
    );
}

=item grant_client_permission( $client )

Grant this role permissions on the specified client.

Arguemnt may be client object or id.

=cut

sub grant_client_permission {
    my $self = shift;
    my ( $client ) = @_;
    my $id = ref $client ? $client->id : $client;

    my $perm = $self->has_direct_client_permission( $client );
    return $perm if $perm;

    $perm = eleMentalClinic::Role::ClientPermission->new({
        role_id => $self->id,
        client_id => $id,
    });
    $perm->save;
    return $perm;
}

=item grant_client_permissions( $client1, $client2_id )

Grant this role permissions on the specified clients.

Arguemnts may be client objects or ids.

=cut

sub grant_client_permissions {
    my $self = shift;
    return [ map { $self->grant_client_permission( $_ ) } @_ ];
}

=item revoke_client_permission( $client )

Revoke a direct client permission.

=cut

sub revoke_client_permission {
    my $self = shift;
    my ( $client ) = @_;

    my $perm = $self->has_direct_client_permission( $client );
    return unless $perm;
    return $perm->delete();
}

=item revoke_client_permissions( $client1, $client2_id )

Revoke the specified direct client permissions.

=cut

sub revoke_client_permissions {
    my $self = shift;
    return [ map { $self->revoke_client_permission( $_ ) } @_ ];
}

=item $list = association_methods( $client )

Returns a list containing all the ways in which this role is granted access to
the specified client.

The current role is included in the list if there is a direct association.

Returned datastructure is a combination of role objects, and hashes containing
group => $groupobj or limited => $roleobj

    return [
        eleMentalClinic::Role->retrieve( ... ),
        eleMentalClinic::Role->retrieve( ... ),
        eleMentalClinic::Role->retrieve( ... ),
        $self,
        { group => eleMentalClinic::Group->retrieve( ... )},
        { group => eleMentalClinic::Group->retrieve( ... )},
        { limited => eleMentalClinic::Role->retrieve( ... )},
    ]

=cut

sub association_methods {
    my $self = shift;
    my ( $client ) = @_;
    my $client_id = ref $client ? $client->id : $client;
    my $parents = $self->_parent_roles;
    my $limited = $self->limited_all_access_roles();

    # All the parent roles that grant us access
    my @items = grep { $_->has_client_permission( $client_id )} @$parents;

    # If we ourselves have direct access
    unshift( @items, $self ) if $self->has_direct_client_permission( $client_id );

    # Each group we have direct access to Don't need to list groups our parents
    # have direct access too, thats captured well enough by listing parents
    # that grant us access.
    push @items => map {{ group => $_ }} grep { $self->has_direct_group_permissions( $_ ) }
        $self->has_client_permission_by_group( $client_id );

    # Limited => role for ourselves if we are a member of
    # limited_all_access_roles. Also for each parent that is a member of
    # limited_all_access_roles.
    push @items => map {{ limited => $_ }}
        (grep { $_->has_direct_member( $self )} @$limited),
        (grep {
            my $parent = $_;
            grep { $_->has_member( $parent )} @$limited
        } @$parents);

    return \@items;
}

#}}}

#{{{ group permission related methods

=item is_all_groups_role()

Returns true if this role is the all_groups special role.

=cut

sub is_all_groups_role {
    my $self = shift;
    return 1 if $self->rec_id == $self->all_groups_role->rec_id;
    return 0;
}

=item has_all_groups_role()

Returns true if this role is a member of the all_groups role.

=cut

sub has_all_groups_role {
    my $self = shift;
    return 1 if $self->is_all_groups_role;
    return 1 if $self->all_groups_role->has_member( $self );
    return 0;
}

=item all_group_permissions()

Returns an arrayref of all the group permissions in this role and parent
roles.

Note: Does not include service coordinator permissions

=cut

sub all_group_permissions {
    my $self = shift;

    my @roles = ( $self, @{ $self->_parent_roles });
    my %permissions = map { $_->id => $_ } map { @{ $_->direct_group_permissions || [] }} @roles;

    return [ values %permissions ];
}

=item has_group_permission( $group )

Returns true if this role has direct or inderect permissions with the specified
group.

Argument may be eleMentalClinic::Group object or ID.

=cut

sub has_group_permission {
    my $self = shift;
    return $self->has_group_permissions( @_ );
}

=item has_group_permissions( $group1, $group2_id, ... )

Returns true if this role has direct or indirect permissions with all the
specified groups.

Arguments may be eleMentalClinic::Group object or ID.

=cut

sub has_group_permissions {
    my $self = shift;
    my @groups = @_;
    my $perms = $self->all_group_permissions || [];
    if ( @$perms ) {
        return $self->_has_(
            $perms,
            \@groups,
            'group_id',
        ) || $self->has_all_groups_role;
    }
    return $self->has_all_groups_role;
}

=item has_direct_group_permission( $group )

Returns true if this role has direct permissions with the specified group.

Argument may be eleMentalClinic::Group object or ID.

=cut

sub has_direct_group_permission {
    my $self = shift;
    my ( $group ) = @_;
    my $id = ref $group ? $group->id : $group;

    my $perm = eleMentalClinic::Role::GroupPermission->get_one_where(
        'WHERE role_id = ' . dbquote( $self->id ) . ' AND group_id = ' . dbquote( $id )
    );
    return $perm if $perm and $perm->id;
    return $self->is_all_groups_role;
}

=item has_group_permissions( $group1, $group2_id, ... )

Returns true if this role has direct permissions with all the specified
groups.

Arguments may be eleMentalClinic::Group object or ID.

=cut

sub has_direct_group_permissions {
    my $self = shift;
    my @groups = @_;
    my $perms = $self->direct_group_permissions;
    return unless $perms;
    return $self->_has_(
        $perms,
        \@groups,
        'group_id',
    );
}

=item grant_group_permission( $group )

Grant this role permissions on the specified group.

Arguemnt may be group object or id.

=cut

sub grant_group_permission {
    my $self = shift;
    my ( $group ) = @_;
    my $id = ref $group ? $group->id : $group;

    my $perm = $self->has_direct_group_permission( $group );
    return $perm if $perm;

    $perm = eleMentalClinic::Role::GroupPermission->new({
        role_id => $self->id,
        group_id => $id,
    });
    $perm->save;
    return $perm;
}

=item grant_group_permissions( $group1, $group2_id )

Grant this role permissions on the specified groups.

Arguemnts may be group objects or ids.

=cut

sub grant_group_permissions {
    my $self = shift;
    return [ map { $self->grant_group_permission( $_ ) } @_ ];
}

=item revoke_group_permission( $group )

Revoke a direct group permission.

=cut

sub revoke_group_permission {
    my $self = shift;
    my ( $group ) = @_;

    my $perm = $self->has_direct_group_permission( $group );
    return unless $perm;
    return $perm->delete();
}

=item revoke_group_permissions( $group1, $group2_id )

Revoke the specified direct group permissions.

=cut

sub revoke_group_permissions {
    my $self = shift;
    return [ map { $self->revoke_group_permission( $_ ) } @_ ];
}

#}}}

#{{{ Helper methods

=item $list = _parent_roles()

Get a list of all the roles of which this role is a member.

=cut

sub _parent_roles {
    my $self = shift;
    my $parents = $self->all_parents;
    return [ map { $_->role } @$parents ];
}

=item _recurse_memberships( $method, $position, $seen )

Will recurse through members and members of members and so on retrieving
member objects from self->$method. $position must be one of 'role' or 'member'
to recurse parents or members. $seen is used in internal recursion to prevent
loops in cases of recursive memberships.

=cut

sub _recurse_memberships {
    my $self = shift;
    my ( $method, $position, $seen ) = @_;
    $seen ||= {};
    my $pmethod = $position . "_id";

    # Get all the direct members or parents not already seen
    my $direct = $self->$method;
    return unless $direct and @$direct;
    $direct = [ grep { ! $seen->{ $_->$pmethod }} @$direct ];
    return unless $direct and @$direct;

    my $members = { map { $_->$pmethod => $_ } @$direct };

    my $new_seen = { %$members, %$seen };
    $members = {
        %$members,
        # Add all members/parents of the direct members/parents
        map {
            my $all = $_->$position()->_recurse_memberships( $method, $position, $new_seen ) || [];
            map { $_->$pmethod => $_ } grep { $_ } @$all,
        } @$direct
    };

    return [ values %$members ];
}

=item _has_( $have, $want, $in_field )

$have should be an array of objects associated with this role.

$want should be an array of objects or id's we are checking for.

$in_field should be a method on the objects in $have that returns the id of the
objects we want.

Returns true if every object in $want is found in $in_field in the $have items.

This type of search is used often in eleMentalClinic::Role.

=cut

sub _has_ {
    my $self = shift;
    my ( $have, $want, $in_field ) = @_;
    #everything in @$want should be found in @$have->$in_field;

    # ID's for all the objects we 'want'.
    my @need = map { ref($_) ? $_->id : $_ } @$want;

    # Special map of field=>object for all the objects we 'have'
    my %got = map { $_->$in_field => $_ } @$have;

    # What needs do we got? :-)
    my @matches = grep { $got{ $_ }} @need;

    #If both lists are the same length we are good.
    return @matches == @need; 
}

=item _do_personnel( $method, $personnel1, $personnel2, ... )

$method should be 'add_member' or 'del_member'.

Add or remove the specified personnel to this role depending on $method.

Arguments may be personnel objects or ids.

=cut

sub _do_personnel {
    my $self = shift;
    my $method = shift;
    return [ map { $self->_do_personnel( $method, $_ )} @_ ] if @_ > 1;
    my ( $personnel ) = @_;
    return unless $personnel;
    $personnel = eleMentalClinic::Personnel->retrieve( $personnel ) unless ref $personnel;
    my $p_role = $personnel->primary_role;

    $self->$method( $p_role );
}

#}}}

'eleMental';

__END__

=back

=head1 AUTHORS

=over 4

=item Chad Granum L<chad@opensourcery.com>

=back

=head1 BUGS

We strive for perfection but are, in fact, mortal.  Please see L<https://prefect.opensourcery.com:444/projects/elementalclinic/report/1> for known bugs.

=head1 SEE ALSO

=over 4

=item Project web site at: L<http://elementalclinic.org>

=item Code management site at: L<https://prefect.opensourcery.com:444/projects/elementalclinic/>

=back

=head1 COPYRIGHT

Copyright (C) 2004-2009 OpenSourcery, LLC

This file is part of eleMental Clinic.

eleMental Clinic is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the Free
Software Foundation; either version 2 of the License, or (at your option) any
later version.

eleMental Clinic is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with
this program; if not, write to the Free Software Foundation, Inc., 51 Franklin
Street, Fifth Floor, Boston, MA 02110-1301 USA.

eleMental Clinic is packaged with a copy of the GNU General Public License.
Please see docs/COPYING in this distribution.
